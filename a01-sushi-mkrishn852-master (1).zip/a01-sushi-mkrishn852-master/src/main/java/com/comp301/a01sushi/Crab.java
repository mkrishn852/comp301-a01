package com.comp301.a01sushi;

public class Crab extends ParentIngredient {

  public Crab() {
    super("crab", 0.72, 37, false, false, true);
  }
}
