package com.comp301.a01sushi;

public class Tuna extends ParentIngredient {

  public Tuna() {
    super("tuna", 1.67, 42, false, false, false);
  }
}
