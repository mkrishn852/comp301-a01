package com.comp301.a01sushi;

public class Yellowtail extends ParentIngredient {

  public Yellowtail() {
    super("yellowtail", 0.74, 57, false, false, false);
  }
}
