package com.comp301.a01sushi;

public class Shrimp extends ParentIngredient {

  public Shrimp() {
    super("shrimp", 0.65, 32, false, false, true);
  }
}
