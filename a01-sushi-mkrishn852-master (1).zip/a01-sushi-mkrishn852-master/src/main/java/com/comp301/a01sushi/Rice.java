package com.comp301.a01sushi;

public class Rice extends ParentIngredient {

  public Rice() {
    super("rice", 0.13, 34, true, true, false);
  }
}
