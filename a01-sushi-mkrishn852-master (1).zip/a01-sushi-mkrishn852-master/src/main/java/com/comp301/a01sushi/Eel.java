package com.comp301.a01sushi;

public class Eel extends ParentIngredient {

  public Eel() {
    super("eel", 2.15, 82, false, false, false);
  }
}
