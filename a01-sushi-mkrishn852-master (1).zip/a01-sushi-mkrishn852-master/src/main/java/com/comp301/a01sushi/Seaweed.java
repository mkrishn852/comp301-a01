package com.comp301.a01sushi;

public class Seaweed extends ParentIngredient {

  public Seaweed() {
    super("seaweed", 2.85, 105, true, false, false);
  }
}
