package com.comp301.a01sushi;

public class Avocado extends ParentIngredient {

  public Avocado() {
    super("avocado", 0.24, 42, true, false, false);
  }
}
